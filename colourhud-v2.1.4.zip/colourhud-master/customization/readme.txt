Edit .res files like text files.

Uncommenting is removing //
Commenting is vice versa.