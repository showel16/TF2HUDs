# BX Hud


<a>LINKS</a>
====

[TeamFortress.tv](https://www.teamfortress.tv/33738/ive-updated-some-huds)

[Screenshot Album](https://imgur.com/a/gGOow)

[Changelogs](https://github.com/Hypnootize/BX-Hud/commits/master)

[Installation](https://imgur.com/a/w3Ah6)

![](https://i.imgur.com/qFiJPK7.jpg)

<a>CREDITS</a>
====
**Created By:** Chippy
