
# deliHUD Neue
## About
I've somewhat come back to the game after 6 years and decided to update the look of the hud, using bLa's deliHud reborn as a base with a focus on readability and contrast.

Chapeau bas to all that kept the hud alive through the years, I was amazed to see that it is still used after so much time has passed.
[Disquse](https://www.teamfortress.tv/21801/disquses-hud-fixes), [Hypnotize](https://huds.tf/site/s-Deli-Hud), [bLa](https://www.teamfortress.tv/60088/delihud-reborn)

## Screenshots
[View Here](https://imgur.com/a/ix8g52d)

## Credits
- bLa - author of deliHud reborn on which this verison is buit on
- Hypnotize - for some tips and allowing me to use the custom materials from Hypnotize hud
- m0re - author of m0rehud which was the base for all versions of deliHud