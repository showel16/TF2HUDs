you cant preload payload cp icons, the only icons that get preloaded are the home icons,
so using those as the point icons works just fine.
You have to configure their .vmt for payload (PL and PLR) cp icons to use the home icons instead.

Thanks to Whisker for this info!