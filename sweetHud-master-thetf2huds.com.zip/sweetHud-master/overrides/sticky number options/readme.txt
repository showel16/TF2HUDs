huddemomanpipes.res is the only file changed for sticky number repositions


sticky number  affects sticky position with minmode on and off
sticky default affects minmode off 