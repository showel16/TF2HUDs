Customizing your HUD

1) Find the folder with the customization you want.
2) Remove the "_" at the end of the folder name to enable it (e.g. `healthcross_` => `healthcross`)

Note: Most customizations will work if you change them in-game. You'll have to type `hud_reloadscheme` into the console or click the reload scheme button on the main menu. If that does not work, restart your game.

Minmode is not a customization. If you want to enable it, use the Toggle Minmode button in the main menu.

If you have other issues then check https://github.com/BingBongBonky/SpaceHUD/wiki