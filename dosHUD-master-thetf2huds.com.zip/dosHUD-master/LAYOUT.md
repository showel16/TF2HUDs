# HUD layout details

> Basically just some notes on things.

- Panel widths:

    - ``80u`` - Ammo
    - ``120u`` - Health
    - ``80u`` - Item
    - ``80u`` - Portrait
    - ``120u`` - Gamemode specific panel
    - ``160u`` - Stats/tracking panel