//// This is a list of what everything in alternatives refers to & where they fit \\\\

To use any of the alternatives, drag the folder you require into the main folder & it will combine or replace into the normal file location

Pride Nyan Cats - materials\console & scripts/chapterbackgrounds
***Drag the folders out of Pride Nyan Cats!!***
2fort: Asexual
Gravelpit: LGBT 
mvm: Bisexual
upward: Trans
xmas: Nonbinary
fullmoon: Pansexual
scream_fortress: Lesbian

CatEnjoyer Edits - resource\ui\hudammoweapons
**Moves ammo & HP towards the crosshair, changes some fonts, moves Player model to the right side of the screen rather than left****
To implement properly, take the folders out of 'FatKitten Edition' & drag them into your main 'hexhud' folder. It will ask if you want to replace files, say Yes!

4 by 3 version 
**If you don't use widescreen, this is for you!!**
Just drag the resource folder into your main directory to the main folder & it will fix the main menu for you!!

16 by 10 version 
Just drag the resource & scripts folders into your main directory to the main folder & it will fix the main menu for you!!

Spy Menu alternative for Ta5k
Just drag the disguise_menu into resource/ui 

Wild West Theme (for Nate)
Just drag the folders inside "Wild West Theme" & put them into the main folder directory

Galaxy backgrounds
***Drag the folders out of Galaxy Backgrounds!!***
Credits to Ellie (@address.astro on insta)

Alt Damage Numbers
Drag the folders inside "Alt Damage Numbers" & it will change your numbers to the alt font!

Yellow Respawn Numbers
Drag the folders inside "Yellow Respawn Numbers" into your main folder to change the color of your respawn numbers!

Spedometer
Drag the folders inside "Spedometer" into your main folder to add a spedometer at the bottom of your screen, above cap points!

Chronos edition (Custom for my friend)
Drag the folders inside "Chronos edition" into your main folder to change some fonts

berryhud after dark
Drag the folders inside "berryhud after dark" into your main folder, and it will change all your backgrounds!

Transparent Viewmodels
Make a copy of your regular scripts/hudlayout.res, Drag the folders inside "Transparent Viewmodels" into your main folder, and add 'exec enable_transparency' to your autoexec.cfg. To revert, overwrite scripts/hudlayout.res with the copy.
